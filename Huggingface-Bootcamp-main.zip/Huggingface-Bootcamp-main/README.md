# live youtube video -- >40 comments , > 100 likes , > 40 share 
# https://www.youtube.com/live/QSWFG7Rj9c4
